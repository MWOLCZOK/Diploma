﻿Public MustInherit Class Entity
    Public Property Id As Long


End Class
