﻿Public Class Patente
    Inherits PermisoComponent

    Public Property Permiso As TipoPermisoPatente

    Public Overrides Sub AgregarPermiso(permiso As PermisoComponent)

    End Sub



    Public Overrides Sub QuitarPermiso(permiso As PermisoComponent)

    End Sub

    Public Overrides Function ObtenerHijos() As IList(Of PermisoComponent)
        Return New List(Of PermisoComponent)
    End Function
End Class
