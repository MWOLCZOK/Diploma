﻿Public Enum TipoPermisoPatente
    GestorPermisos
    AltaUsuario

    AsignarPermisos

End Enum
