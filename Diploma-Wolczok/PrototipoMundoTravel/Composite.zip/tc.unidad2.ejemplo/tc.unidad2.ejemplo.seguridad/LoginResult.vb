﻿Public Enum LoginResult
    InvalidUsername
    InvalidPassword
    ValidUser
End Enum
