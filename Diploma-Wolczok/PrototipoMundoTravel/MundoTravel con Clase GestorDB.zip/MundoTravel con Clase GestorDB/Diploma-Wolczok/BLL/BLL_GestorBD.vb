﻿Imports DAL

Public Class BLL_GestorBD

    Public Sub gestorBD()
        DAL.GestorBD.ObtenerInstancia.ConfiguracionInicial()
    End Sub

End Class
