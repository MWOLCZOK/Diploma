﻿Public Interface BLL_Iobservador

    Sub actualizarIdioma(ByVal ParamObservador As BLL_SesionObservada)

End Interface
