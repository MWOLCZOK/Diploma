﻿Public Class CamposIncompletosException
    Inherits System.Exception

End Class
