﻿Public Class PasswordIncorrectoException
    Inherits System.Exception

End Class
