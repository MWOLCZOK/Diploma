﻿Public Class UsuarioBloqueadoException
    Inherits System.Exception
End Class
