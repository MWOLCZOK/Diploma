﻿Public Class usuarioInexistenteException
    Inherits System.Exception
End Class
