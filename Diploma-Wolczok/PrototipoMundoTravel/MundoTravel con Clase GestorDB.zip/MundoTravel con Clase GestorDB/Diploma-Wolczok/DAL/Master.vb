﻿Public Interface Master
    Sub alta(ByVal paramobjeto As Object)


    Function modificar(ByVal paramobjeto As Object) As Boolean

    Sub eliminar(ByVal paramobjeto As Object)

    'Function ConsultarTodos() As List(Of Object)


    'Function ConsultarUno(ByVal paramobjeto As Object) As Object


End Interface
