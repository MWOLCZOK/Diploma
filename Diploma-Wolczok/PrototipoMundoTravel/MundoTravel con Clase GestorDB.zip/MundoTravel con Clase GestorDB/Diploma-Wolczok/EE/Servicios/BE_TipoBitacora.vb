﻿Public Enum BE_TipoBitacora
    Alta = 1
    Baja = 2
    Modificación = 3
    Errores = 4
    Login = 5
    Backup = 6
    Restore = 7

End Enum

